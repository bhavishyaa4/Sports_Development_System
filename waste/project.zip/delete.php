<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];
    $sql = "DELETE FROM `applicant_register` where id=$id";
    $result = mysqli_query($con,$sql);   
    }
    if($result){
        header('location:applicant.php');
    }
    else{
        die(mysqli_error($con));
}
?>