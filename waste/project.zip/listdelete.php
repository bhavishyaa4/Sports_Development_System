<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];
    $sql = "DELETE FROM `sports_categories` where id=$id";
    $result = mysqli_query($con,$sql);   
    }
    if($result){
        header('location:listsports.php');
    }
    else{
        die(mysqli_error($con));
}
?>