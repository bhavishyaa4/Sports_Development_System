<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    $uname = $_POST['uname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $fname = $_POST['fname'];
    $mobile = $_POST['mobile'];
    $error = array();
    $u = "SELECT email FROM `user_register` WHERE email = '$email'";
    $uu = mysqli_query($con, $u);

    if (empty($uname)) {
        $error['runame'] = "Username is required !!";
    }
    if (empty($email)) {
        $error['remail'] = "Email is required !!";
    }
    if (empty($password)) {
        $error['rpassword'] = "Password is required !!";
    }
    if (empty($fname)) {
        $error['rname'] = "Name is required !!";
    }
    if (empty($mobile)) {
        $error['rmobile'] = "Mobile Number is required !!";
    }

    if (count($error) == 0) {
        $sql = "INSERT INTO `user_register` (username, name, email, gender, number, password) VALUES ('$uname','$fname','$email', '$gender', '$mobile', '$password')";
        $result = mysqli_query($con, $sql);

        if ($result) {
            echo "Data has been inserted";
            // header('location: home.php');
        } else {
            die(mysqli_error($con));
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTER PAGE:</title>
    <link rel="stylesheet" href="ureg.css">
</head>
<body>
    <form class="f-body" name="form" id="form" method="post" action="" enctype="multipart/form-data">
        <h1 style="text-align: center;">REGISTER</h1>
        <div class="info">
            <div class="first">
                <h2 style="font-size: 33px;color:rgb(255, 0, 255);">SportZen</h2>
                <h3 style="padding:0px;margin-left: 15px; margin-top: 30px; color:yellow">ENHANCE</h3>
                <h3 style="padding:0px;margin-left: 30px;color:orange;">AND</h3>
                <h3 style="padding:0px;margin-left: 45px;color:yellow;">DEVELOP</h3>
            </div>
            <div class="second">
                <label>Username</label>
                <input type="text" name="uname" id="uname" autocomplete="off" placeholder="Enter your username" value=""/>
                <p class="require">
                    <?php
                    if (isset($error['runame'])) {
                        echo $error['runame'];
                    }
                    ?>
                </p>
                <label>Email</label>
                <input type="text" name="email" id="email" autocomplete="off" placeholder="Enter your email" value=""/>
                <p class="require">
                    <?php
                    if (isset($error['remail'])) {
                        echo $error['remail'];
                    }
                    ?>
                </p>
                <label>Password</label>
                <input type="password" class="password" id="password" name="password" autocomplete="off" placeholder="****" value=""/>
                <p class="require">
                    <?php
                    if (isset($error['rpassword'])) {
                        echo $error['rpassword'];
                    }
                    ?>
                </p>
                <label>Gender</label>
                <select name="gender">
                    <option value="male">MALE</option>
                    <option value="female">FEMALE</option>
                    <option value="others">OTHERS</option>
                </select>
            </div>
            <div class="third">
                <label>Name</label>
                <input type="text" name="fname" id="fname" autocomplete="off" placeholder="Enter your name" value=""/>
                <p class="require">
                    <?php
                    if (isset($error['rname'])) {
                        echo $error['rname'];
                    }
                    ?>
                </p>
                <label>Number</label>
                <input type="number" name="mobile" id="mobile" autocomplete="off" placeholder="Enter your number"  value=""/>
                <p class="require">
                    <?php
                    if (isset($error['rmobile'])) {
                        echo $error['rmobile'];
                    }
                    ?>
                </p>
                <label>C.Password</label>
                <input type="password" name="cpass" id="cpass" autocomplete="off" placeholder="***" value=""/>
            </div>
        </div>
        <button class="footer" name="submit">SIGN-UP</button>
    </form>
</body>
</html>
