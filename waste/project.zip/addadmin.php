<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('location: ./first.php?err=1');
    exit;
}

include 'connect.php';

$name = $username = $email = $password = $role = $status = '';
$err = [];
$success_message = '';

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    $encrypted_password = md5($password);

    if (empty($name)) {
        $err['name'] = 'Name is required.';
    }
    if (empty($username)) {
        $err['username'] = 'Username is required.';
    }
    if (empty($email)) {
        $err['email'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err['email'] = 'Invalid email address.';
    }
    if (empty($password)) {
        $err['password'] = 'Password is required.';
    }
    if (empty($role)) {
        $err['role'] = 'Role is required.';
    }

    if (empty($err)) {
        $stmt = $con->prepare("INSERT INTO admins (name, username, email, password, role, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $username, $email, $encrypted_password, $role, $status);

        if ($stmt->execute()) {
            $success_message = "Data has been inserted successfully.";
        } else {
            $err['database'] = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$con->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=".css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>HOME PAGE</title>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
        .header{
            width: 100%;
            height: 90px;
            background-color: grey;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        ul{
            display: flex;
        }
        li{
            margin-left: 20px;
            list-style: none;
        }
        li a{
            text-decoration: none;
            color: black;
        }

        .header #logo{
    top: 20px;
    font-size: 30px;
    z-index: 997;
    font-weight: bold;
    color: yellow;
    margin-left: 20px;
}
.logout{
    margin-right: 20px;
}
.logout{
    height: 50px;
    width: 120px;
    top: 20px;
    right: 3%;
    display:grid;
    place-items: center;
    background:lime;
    border-radius: 1px 30px;
    font-weight: bold;
}
.logout:hover{
    background-color: orangered;
}
.logout a{
    color:black;
}
#navbar ul :not(:last-child) a:hover,
#navbar ul :not(:last-child) a:focus{
    border-bottom:2px solid white;
    border-radius: 1px 11px;
}
#navbar ul li{
    font-size: 22px;
    font-weight:    bold;
    margin: 0 40px;
}
#navbar ul li a{
    text-decoration: none;
    color: purple;
}
#navbar ul li a:hover{
    color:blue;
}
.content{
    display:flex;
    flex-direction: column;
    padding-left: 1%;
}
.content h1{
    margin-top: 5%;
}
.content p{
    margin-top: 10%;
}
h1{
    text-decoration: underline;
    font-style: italic;
    font-size: 350%;
}
h1:hover{
    color: lime;
    transition: 0.5s;
}
p{
    font-style:italic;
    font-size: 250%;
    font-weight: bold;
}
p:hover{
    color:orange;
    transition: 0.5s;
}
.icon{
    position:fixed;
    top:25%;
    height:400px;
    width:50px;
    margin-left:96%;
    background-color: grey;
    border-radius: 60px 0 0 60px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-direction: column;
}
.icon:hover{
    background-color: black;
}
.icon a{
    color:yellow;
}
.icon a:hover{
    color:red;
}
.info {
    display:grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap:10px;
    height:500px;
    margin: 0 auto;
    margin-top:30px;
    padding: 10px;
    border-radius: 4px;
}

.info h2, .info h3 {
    text-align: left;
    font-size: larger;
}
.first {
    padding: 15px;
    border-radius: 5px;
    /* box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); */
}
.second, .third {
    padding: 0px;
    margin-right: 45px;
}

.second label, .third label {
    display: grid;
    margin-bottom: 12px;
    font-weight: bold;
    color:black;
}

.second input[type="text"], .second input[type="password"], .second select, .third input[type="text"], .third input[type="number"], .third input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid grey;
    border-radius: 5px;
    box-shadow: none;
    font-size: 14px;
    color: black;
    margin-bottom: 10px;
}
.footer {
    width: 100px;
    margin: 0 auto;
    margin-top: 0px;
    margin-left:270px;
    background-color: #4CAF50;
    color: white;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
}
#myForm{
    margin-left: 450px;
}
.error-message {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div id="logo">SportsZen</div>
        <div id="navbar">
            <ul>
                <li><a href="userhome.php">Home</a></li>
                <li><a href="addsports.php">Add Sports Academy</a></li>
                <li><a href="listsports.php">List Sports Academy</a></li>
                <li><a href="listuser.php">List Users</a></li>
                <li><a href="applicant.php">List Applicant</a></li>
                <li><a href="addadmin.php">Add Admin</a></li>
            </ul>
        </div>
        <div class="out">
            <button class="logout"><a href="logout.php">LOG-OUT</a></button>
        </div>
    </div>
    <form method="post" enctype="multipart/form-data" id="myForm">
    <div class="info">
                <div class="second">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" autocomplete="off" placeholder="Enter your name" value="<?php echo $name; ?>">
                    <?php if (isset($err['name'])): ?>
                        <p class="error-message"><?php echo $err['name']; ?></p>
                    <?php endif; ?>

                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" autocomplete="off" placeholder="Enter your email" value="<?php echo $email; ?>">
                    <?php if (isset($err['email'])): ?>
                        <p class="error-message"><?php echo $err['email']; ?></p>
                    <?php endif; ?>

                    <label for="pass">Password</label>
                    <input type="password" class="password" id="pass" name="password" autocomplete="off" placeholder="****" value="<?php echo $password; ?>">
                    <?php if (isset($err['password'])): ?>
                        <p class="error-message"><?php echo $err['password']; ?></p>
                    <?php endif; ?>

                    <label for="status">Status:</label>
                    <select id="status" name="status">
                        <option value="select">Choose Status</option>
                        <option value="1">Active</option>
                        <option value="0">Not Active</option>
                    </select>
                    <?php if (isset($err['status'])): ?>
                        <p class="error-message"><?php echo $err['status']; ?></p>
                    <?php endif; ?>
                </div>
                <div class="third">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" autocomplete="off" placeholder="Enter your username" value="<?php echo $username; ?>">
                    <?php if (isset($err['username'])): ?>
                        <p class="error-message"><?php echo $err['username']; ?></p>
                    <?php endif; ?>

                    <label for="role">Role</label>
                    <input type="text" name="role" id="role" autocomplete="off" placeholder="Enter your role" value="<?php echo $role; ?>">
                    <?php if (isset($err['role'])): ?>
                        <p class="error-message"><?php echo $err['role']; ?></p>
                    <?php endif; ?>

                    <label for="cpass">Confirm Password</label>
                    <input type="password" name="cpass" autocomplete="off" id="cpass" placeholder="****" value="">
                </div>
            </div>
            <?php if (isset($err['database'])): ?>
                <p class="error-message"><?php echo $err['database']; ?></p>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <p><?php echo $success_message; ?></p>
            <?php endif; ?>
            <div id="error-container"></div>
            <button type="submit" name="submit" class="footer">ADD</button>
        </form>
    </div>
    <script>
        document.getElementById('myForm').addEventListener('submit', function (event) {
  event.preventDefault();

  // Get form field values
  var name = document.getElementById('name').value;
  var username = document.getElementById('username').value;
  var email = document.getElementById('email').value;
  var password = document.getElementById('pass').value;
  var confirmPassword = document.getElementById('cpass').value;
  var role = document.getElementById('role').value;

  // Regular expressions for validation
  var nameRegex = /^[a-zA-Z\s]*$/;
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Error messages
  var errors = [];

  // Validate name
  if (!nameRegex.test(name)) {
    errors.push("Invalid Name: Name must not contain numbers or special characters.");
    alert("Invalid Name: Name must not contain numbers or special characters.");
  }

  // Validate email format
  if (!emailRegex.test(email)) {
    errors.push("Invalid Email: Please enter a valid email address.");
    alert("Invalid Email: Please enter a valid email address.");
  }

  // Validate role
  if (role.trim() === '') {
    errors.push("Empty Role: Role must not be empty.");
    alert("Empty Role: Role must not be empty.");
  }

  // Validate password and confirm password
  if (password !== confirmPassword) {
    errors.push("Password Mismatch: Password and Confirm Password must match.");
    alert("Password Mismatch: Password and Confirm Password must match.");
  }

  // Display error messages or submit the form
  if (errors.length > 0) {
    var errorContainer = document.getElementById('error-container');
    errorContainer.innerHTML = '';

    for (var i = 0; i < errors.length; i++) {
      var error = document.createElement('p');
      error.textContent = errors[i];
      errorContainer.appendChild(error);
    }
  } else {
    this.submit();
  }
});
    </script>
</body>
</html>
